package com.bigao.backend.util;

/**
 * Created by wait on 2015/11/28.
 */
public interface CommonParam {
    /** url传参数里面的选中的server的key值 */
    String SERVER_KEY = "server";
}
