package com.bigao.backend.module.task.vo;

/**
 * Created by wait on 2016/1/18.
 */
public class TaskCount {
    private int taskId;
    private int num;

    public int getTaskId() {
        return taskId;
    }

    public void setTaskId(int taskId) {
        this.taskId = taskId;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }
}
