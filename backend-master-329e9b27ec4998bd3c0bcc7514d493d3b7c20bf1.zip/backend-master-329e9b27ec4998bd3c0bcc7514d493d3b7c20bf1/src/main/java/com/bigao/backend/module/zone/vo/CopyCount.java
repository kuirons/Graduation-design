package com.bigao.backend.module.zone.vo;

/**
 * Created by wait on 2016/2/24.
 */
public class CopyCount {
    private String copyType;
    private int count;

    public String getCopyType() {
        return copyType;
    }

    public void setCopyType(String copyType) {
        this.copyType = copyType;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }
}
