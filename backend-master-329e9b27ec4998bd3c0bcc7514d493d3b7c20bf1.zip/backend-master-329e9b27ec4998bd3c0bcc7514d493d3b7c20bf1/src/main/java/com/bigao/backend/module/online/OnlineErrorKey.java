package com.bigao.backend.module.online;

import com.bigao.backend.util.CommonErrorKey;

/**
 * Created by wait on 2015/12/28.
 */
public interface OnlineErrorKey extends CommonErrorKey{
}
