package com.bigao.backend.mapper;

/**
 * Created by wait on 2015/11/27.
 */
public interface OnlineMapper {
}
