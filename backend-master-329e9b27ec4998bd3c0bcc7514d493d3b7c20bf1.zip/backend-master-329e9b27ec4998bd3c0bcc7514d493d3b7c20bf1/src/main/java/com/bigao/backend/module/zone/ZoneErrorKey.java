package com.bigao.backend.module.zone;

import com.bigao.backend.util.CommonErrorKey;

/**
 * Created by wait on 2015/12/28.
 */
public interface ZoneErrorKey extends CommonErrorKey{
}
