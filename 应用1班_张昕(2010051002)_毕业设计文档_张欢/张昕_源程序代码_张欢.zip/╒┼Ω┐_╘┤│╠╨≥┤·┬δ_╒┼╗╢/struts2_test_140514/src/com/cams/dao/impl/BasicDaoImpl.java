package com.cams.dao.impl;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.cams.dao.BasicDao;

public class BasicDaoImpl implements BasicDao {
	public SessionFactory getSessionFactory() throws HibernateException{
		Configuration cfg = new Configuration().configure();
		SessionFactory sf = null;
		sf = cfg.buildSessionFactory();
		return sf;
	}
	/*
	 * ���д�ϴ����쳣�Ĵ���
	 */
	public void close(Session s) {
		if (s != null) {
			try{
				s.close();
			}catch(HibernateException e){
				e.printStackTrace();
			}
		}
	}

	public void close(SessionFactory sf) {
		if (sf != null) {
			try{
				sf.close();
			}catch(HibernateException e){
				e.printStackTrace();
			}
		}
	}
}
