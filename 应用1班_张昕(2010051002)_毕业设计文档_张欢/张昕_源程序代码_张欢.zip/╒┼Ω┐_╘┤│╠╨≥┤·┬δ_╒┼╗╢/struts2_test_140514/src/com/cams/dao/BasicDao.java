package com.cams.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
/**
 * �������ݿ����Ӻ���Դ�ر�
 * @author Administrator
 *
 */
public interface BasicDao {
	public SessionFactory getSessionFactory() throws HibernateException;
	void close(Session s);
	void close(SessionFactory sf);
}
