package com.cams.controlor;

import com.cams.dao.impl.EquipmentDaoImpl;
import com.opensymphony.xwork2.ActionSupport;

public class PageActionE extends ActionSupport{
	private int pageNumber = 1;
	private int totalPage;
	private int pageSize;
	
	public int getPageNumber() {
		return pageNumber;
	}


	public void setPageNumber(int pageNumber) {
		this.pageNumber = pageNumber;
	}


	public int getTotalPage() {
		return totalPage;
	}


	public void setTotalPage(int totalPage) {
		this.totalPage = totalPage;
	}


	public int getPageSize() {
		return pageSize;
	}


	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}


	public String execute(){
		EquipmentDaoImpl pd = new EquipmentDaoImpl();
		pageSize = 10;
		int plateAmount = pd.getEquipmentAmount();
		// �����ҳ��
		this.totalPage = plateAmount % pageSize == 0 ? (plateAmount / pageSize) : (plateAmount / pageSize + 1);
		if(this.pageNumber < 0){
			this.pageNumber = 1;
		}
		if(this.pageNumber > totalPage){
			this.pageNumber = totalPage;
		}
		return SUCCESS;
	}
}
