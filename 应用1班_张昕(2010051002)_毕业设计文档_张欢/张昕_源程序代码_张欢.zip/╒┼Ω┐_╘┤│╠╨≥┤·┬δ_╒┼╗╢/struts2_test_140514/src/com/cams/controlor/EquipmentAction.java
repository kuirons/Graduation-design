package com.cams.controlor;

import java.util.List;

import com.cams.dao.EquipmentDao;
import com.cams.dao.impl.EquipmentDaoImpl;
import com.cams.entity.Equipment;
import com.opensymphony.xwork2.ActionSupport;
/**
 * ������EquipmentAction
 * ���ߣ����
 * �������ڣ�2014/05/13
 * 
 * ���ã���װ�˹���Equipment��������з���
 * 
 * �޸����ڣ�����
 * ԭ������
 */
public class EquipmentAction extends ActionSupport{
	private List<Equipment> equipments;
	private int id;
	Equipment p;
	private int pageNumber = 1;
	private int totalPage;
	private int pageSize;
	
	// �豸������
	private String name;
	// �豸�����к�
	private String sn;
	// ���豸�Ƿ���ʹ����
	private Integer isUse;
	// ���豸�������ڵ�λ��
	private String location;
	// ���豸��������
	private String type;
	// ���豸���滻����
	private String replaceType;
	// �Դ��豸�ı�ע
	private String note;

	public List<Equipment> getEquipments() {
		return equipments;
	}
	public void setEquipments(List<Equipment> equipments) {
		this.equipments = equipments;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Equipment getP() {
		return p;
	}
	public void setP(Equipment p) {
		this.p = p;
	}
	public int getPageNumber() {
		return pageNumber;
	}
	public void setPageNumber(int pageNumber) {
		this.pageNumber = pageNumber;
	}
	public int getTotalPage() {
		return totalPage;
	}
	public void setTotalPage(int totalPage) {
		this.totalPage = totalPage;
	}
	public int getPageSize() {
		return pageSize;
	}
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSn() {
		return sn;
	}
	public void setSn(String sn) {
		this.sn = sn;
	}
	public Integer getIsUse() {
		return isUse;
	}
	public void setIsUse(Integer isUse) {
		this.isUse = isUse;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getReplaceType() {
		return replaceType;
	}
	public void setReplaceType(String replaceType) {
		this.replaceType = replaceType;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}

	/**
	 * ��������list
	 * ���ߣ����
	 * �������ڣ�2014/05/13
	 * 
	 * ���ã��������е�Equipment����
	 * 
	 * �޸����ڣ�����
	 * ԭ������
	 */
	public String list() {
		EquipmentDao pd = new EquipmentDaoImpl();
		equipments = pd.getAllEquipments();
		return SUCCESS;
	}
	public String listByPage(){
		EquipmentDaoImpl pd = new EquipmentDaoImpl();
		equipments = pd.getEquipmentByPage(pageNumber, pageSize);
		return SUCCESS;
	}
	public String get(){
		EquipmentDao pd = new EquipmentDaoImpl();
		p = pd.getEquipmentById(id);
		return SUCCESS;
	}
	
	public String add() {
		EquipmentDao pd = new EquipmentDaoImpl();
		p = new Equipment(id,name,sn,isUse,location,type,replaceType,note);
		pd.addEquipment(p);
		return SUCCESS;
	}
	public String update() {
		EquipmentDao pd = new EquipmentDaoImpl();
		System.out.println(id + "  " + name);
		p = new Equipment(id,name,sn,isUse,location,type,replaceType,note);
		pd.setEquipment(id, p.getName(), p.getSn(), p.getIsUse(), p.getLocation(), p.getType(), p.getReplaceType(), p.getNote());
		return SUCCESS;
	}
	public String delete() {
		EquipmentDao pd = new EquipmentDaoImpl();
		pd.delEquipment(id);
		return SUCCESS;
	}
	
}
