package com.cams.controlor;

import java.util.List;

import com.cams.dao.PlateDao;
import com.cams.dao.impl.PlateDaoImpl;
import com.cams.entity.Plate;
import com.opensymphony.xwork2.ActionSupport;
/**
 * ������PlateAction
 * ���ߣ����
 * �������ڣ�2014/05/13
 * 
 * ���ã���װ�˹���Plate��������з���
 * 
 * �޸����ڣ�����
 * ԭ������
 */
public class PlateAction extends ActionSupport{
	private List<Plate> plates;
	private int id;
	Plate p;
	private int pageNumber = 1;
	private int totalPage;
	private int pageSize;
	
	// ��ĵ�����
	private String name;
	// ��ĵ����к�
	private String sn;
	// �ð���Ƿ���ʹ����
	private Integer isUse;
	// �ð���������ڵ�λ��
	private String location;
	// �ð����������
	private String type;
	// �ð�ĵ��滻����
	private String replaceType;
	// �Դ˰�ĵı�ע
	private String note;

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Plate getP() {
		return p;
	}
	public void setP(Plate p) {
		this.p = p;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSn() {
		return sn;
	}
	public void setSn(String sn) {
		this.sn = sn;
	}
	public Integer getIsUse() {
		return isUse;
	}
	public void setIsUse(Integer isUse) {
		this.isUse = isUse;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getReplaceType() {
		return replaceType;
	}
	public void setReplaceType(String replaceType) {
		this.replaceType = replaceType;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	public List<Plate> getPlates() {
		return plates;
	}
	public void setPlates(List<Plate> plates) {
		this.plates = plates;
	}
	public int getPageNumber() {
		return pageNumber;
	}


	public void setPageNumber(int pageNumber) {
		this.pageNumber = pageNumber;
	}


	public int getTotalPage() {
		return totalPage;
	}


	public void setTotalPage(int totalPage) {
		this.totalPage = totalPage;
	}


	public int getPageSize() {
		return pageSize;
	}


	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
	/**
	 * ��������list
	 * ���ߣ����
	 * �������ڣ�2014/05/13
	 * 
	 * ���ã��������е�Plate����
	 * 
	 * �޸����ڣ�����
	 * ԭ������
	 */
	public String list() {
		PlateDao pd = new PlateDaoImpl();
		plates = pd.getAllPlates();
		return SUCCESS;
	}
	public String listByPage(){
		PlateDao pd = new PlateDaoImpl();
		plates = pd.getPlateByPage(pageNumber, pageSize);
		return SUCCESS;
	}
	public String get(){
		PlateDao pd = new PlateDaoImpl();
		p = pd.getPlateById(id);
		return SUCCESS;
	}
	
	public String add() {
		PlateDao pd = new PlateDaoImpl();
		p = new Plate(id,name,sn,isUse,location,type,replaceType,note);
		pd.addPlate(p);
		return SUCCESS;
	}
	public String update() {
		PlateDao pd = new PlateDaoImpl();
		System.out.println(id + "  " + name);
		p = new Plate(id,name,sn,isUse,location,type,replaceType,note);
		pd.setPlate(id, p.getName(), p.getSn(), p.getIsUse(), p.getLocation(), p.getType(), p.getReplaceType(), p.getNote());
		return SUCCESS;
	}
	public String delete() {
		PlateDao pd = new PlateDaoImpl();
		pd.delPlate(id);
		return SUCCESS;
	}
	
	public String updateInput() {
		PlateDao pd = new PlateDaoImpl();
		return "input";
	}
}
